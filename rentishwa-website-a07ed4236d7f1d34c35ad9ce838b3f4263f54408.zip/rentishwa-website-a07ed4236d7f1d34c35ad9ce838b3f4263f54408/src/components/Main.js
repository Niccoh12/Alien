import About from "./About";
import Services from "./Services";
import Contact from "./Contact";

function Main() {
  return (
    <>
      <main></main>
    </>
  );
}
export default Main;
