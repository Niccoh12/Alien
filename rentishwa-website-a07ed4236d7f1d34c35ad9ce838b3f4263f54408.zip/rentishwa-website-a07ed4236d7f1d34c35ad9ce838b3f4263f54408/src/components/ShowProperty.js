import React from "react";

function ShowProperty() {
  return <div></div>;
}

export default ShowProperty;
